# yolov10 > 2024-09-08 8:06am
https://universe.roboflow.com/yolo-tzsgj/yolov10-tstfr

Provided by a Roboflow user
License: CC BY 4.0

