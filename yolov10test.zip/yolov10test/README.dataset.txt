# yolov10 > 2024-08-29 6:44am
https://universe.roboflow.com/yolo-tzsgj/yolov10-tstfr

Provided by a Roboflow user
License: CC BY 4.0

